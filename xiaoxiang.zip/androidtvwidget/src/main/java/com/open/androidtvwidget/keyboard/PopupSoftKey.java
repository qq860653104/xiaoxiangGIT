package com.open.androidtvwidget.keyboard;

import java.util.List;

/***
 * 用于弹出T9键盘或者弹出其它界面的按键.
 * 
 * @author hailongqiu
 *
 */
public class PopupSoftKey extends SoftKey {
}
