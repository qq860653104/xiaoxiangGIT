package com.open.androidtvwidget.utils;

import android.graphics.Bitmap;

/**
 * Created by wh on 2018/3/16.
 */

public class XiaoCuiTag {

    public static Bitmap getCaCheBitMap() {
        return caCheBitMap;
    }

    public static void setCaCheBitMap(Bitmap caCheBitMap) {
        XiaoCuiTag.caCheBitMap = caCheBitMap;
    }

    public static Bitmap caCheBitMap;

    public static String[] myStr = {""};

}
