package com.open.androidtvwidget.view;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;

public class ViewPagerTV extends ViewPager {

	public ViewPagerTV(Context context) {
		super(context);
	}
	
	public ViewPagerTV(Context context, AttributeSet attrs) {
		super(context, attrs);
	}
	
}
