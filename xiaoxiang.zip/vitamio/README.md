Vitamio
===============

This folder contains the main library which should be linked against as an
Android library project in your application.
