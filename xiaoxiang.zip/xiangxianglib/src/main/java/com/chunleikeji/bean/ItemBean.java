package com.chunleikeji.bean;

public class ItemBean {

    /**
     * id : 3931
     * is_vip : 0
     * number : 1
     */

    private String id;
    private String is_vip;
    private int number;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIs_vip() {
        return is_vip;
    }

    public void setIs_vip(String is_vip) {
        this.is_vip = is_vip;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }


}
