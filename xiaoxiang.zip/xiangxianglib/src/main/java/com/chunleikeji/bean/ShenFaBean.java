package com.chunleikeji.bean;

/**
 * Created by wh on 2018-08-26.
 */

public class ShenFaBean {


    /**
     * msg : 通过
     * tag : 1
     */

    private String msg;
    private String tag;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}
