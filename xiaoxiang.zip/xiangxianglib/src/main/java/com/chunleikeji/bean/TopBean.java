package com.chunleikeji.bean;

import java.util.List;

public class TopBean {


    private List<DianboBean.DataBean.ListBean> list;

    public List<DianboBean.DataBean.ListBean> getList() {
        return list;
    }

    public void setList(List<DianboBean.DataBean.ListBean> list) {
        this.list = list;
    }


}
