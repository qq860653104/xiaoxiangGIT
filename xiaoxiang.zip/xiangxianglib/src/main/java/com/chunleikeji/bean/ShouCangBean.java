package com.chunleikeji.bean;

import java.util.ArrayList;

/**
 * Created by wh on 2018/3/17.
 */

public class ShouCangBean {

    public ArrayList<ScMovieBean> getMovieList() {
        return movieList;
    }

    public void setMovieList(ArrayList<ScMovieBean> movieList) {
        this.movieList = movieList;
    }

     ArrayList<ScMovieBean> movieList;




}
