package com.chunleikeji.bean;

public class Test {


    /**
     * msg : 您账号已被顶替，请检查或联系管理员！
     * tag : 1
     * vip : 1
     * end : 2019-07-16
     */

    private String msg;
    private String tag;
    private int vip;
    private String end;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public int getVip() {
        return vip;
    }

    public void setVip(int vip) {
        this.vip = vip;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }
}
