package com.chunleikeji.zhibotv;

public class TVTabBean {

    public String Name;
    public String url;
    public int id;
    public TVTabBean(String tabName, String url){
        this.Name = tabName;
        this.url = url;
    }


}
