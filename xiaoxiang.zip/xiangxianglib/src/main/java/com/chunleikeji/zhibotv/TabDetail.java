package com.chunleikeji.zhibotv;

public class TabDetail {
    public String name="未知";
    public String detail="暂无节目信息";
    public String url;
}
