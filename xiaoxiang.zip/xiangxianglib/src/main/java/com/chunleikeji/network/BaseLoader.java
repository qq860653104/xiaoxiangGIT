package com.chunleikeji.network;

import android.content.Context;
import android.content.Loader;

/**
 * Created by hailongqiu on 2016/9/4.
 */
public class BaseLoader extends Loader<Object> {

    public BaseLoader(Context context) {
        super(context);
    }
    
}
