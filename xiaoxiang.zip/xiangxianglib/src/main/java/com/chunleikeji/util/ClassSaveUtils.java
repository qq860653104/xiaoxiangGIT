package com.chunleikeji.util;

public class ClassSaveUtils {

  public static   Class CarouselImgActivity;
  public static   Class MainActivity;
  public static   Class DetailInfoActivity;



}
