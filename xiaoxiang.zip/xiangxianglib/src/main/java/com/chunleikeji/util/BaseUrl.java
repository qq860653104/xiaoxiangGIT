package com.chunleikeji.util;

public class BaseUrl {

    public static String BASE = "http://39.105.70.121/test3/MeiJiaDian/chuanbojiekou/think_test/public/index.php/index/index/";
    public static String Update_BASE = "http://39.105.70.121/test3/MeiJiaDian/chuanbojiekou/think_test/public/index.php/index/index/";
//http://39.105.70.121/test3/MeiJiaDian/chuanbojiekou/think_test/public/index.php/index/index/getVideoAndImage?type=
//http://39.105.70.121/test3/MeiJiaDian/chuanbojiekou/think_test/public/index.php/index/index/
}
//http://39.105.70.121/test3/v3final/chuanbojiekou/think_test/public/index.php/index/index/